package com.tweetapp.authenticationService.exception;

public class UnregisteredEmailIdException extends RuntimeException {

    public UnregisteredEmailIdException(String message) {
        super(message);
    }

}
