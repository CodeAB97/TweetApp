package com.tweetapp.authenticationService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tweetapp.authenticationService.model.User;
import com.tweetapp.authenticationService.model.UserDetails;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.util.List;

@Service
public interface AuthenticationService {

    void registerUser(User user) throws JsonProcessingException;

    User fetchUserByUsername(String userName);

    List<UserDetails> getAllUsers() throws JsonProcessingException;

    List<UserDetails> searchByUserName(String userName) throws JsonProcessingException;

    Boolean forgotPassword(String userName, String emailId) throws MessagingException;

    void updateOtpData(String eventMessage);

    Boolean verifyOtp(String userName, String otp);

    void resetPassword(String userName, String newPassword);

}
