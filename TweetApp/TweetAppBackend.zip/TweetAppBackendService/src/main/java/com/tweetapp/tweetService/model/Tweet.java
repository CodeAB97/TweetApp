package com.tweetapp.tweetService.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tweet implements Comparable<Tweet> {

    @Id
    private String id;
    private String userName;
    private String firstName;
    private String lastName;
    private String tweetText;
    private Date time;
    private List<String> likes;
    private List<TweetReplies> tweetReplies;

    @Override
    public int compareTo(Tweet o) {
        if (time.before(o.getTime())) {
            return 1;
        } else if (time.after(o.getTime())) {
            return -1;
        }
        return 0;
    }

}
