package com.tweetapp.authenticationService.controller;

import com.tweetapp.authenticationService.exception.UnregisteredEmailIdException;
import com.tweetapp.authenticationService.model.ResponseMessage;
import com.tweetapp.authenticationService.model.User;
import com.tweetapp.authenticationService.model.UserDetails;
import com.tweetapp.authenticationService.service.AuthenticationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.util.List;

@RestController
@RequestMapping("/api/v1.0/tweets")
@CrossOrigin(origins = "*")
public class AuthenticationServiceController {

    private final Logger logger = LoggerFactory.getLogger(AuthenticationServiceController.class);

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/register")
    public ResponseEntity<ResponseMessage> registerUser(@RequestBody User user) {
        try {
            logger.debug("Request received inside AuthenticationServiceController for registering user : " + user.getUserName());
            authenticationService.registerUser(user);
            logger.debug(String.format("User : %s registered successfully. Returning response with status 201:CREATED", user.getUserName()));
            return new ResponseEntity<>(new ResponseMessage("User Registration Successful"), HttpStatus.CREATED);
        } catch (DuplicateKeyException e) {
            if (e.getMessage() != null && e.getMessage().contains("userName")) {
                logger.debug(String.format("User : %s registration failed. Username not unique. Returning response with status 400:BAD_REQUEST", user.getUserName()));
                return new ResponseEntity<>(new ResponseMessage("UserName is not unique"), HttpStatus.BAD_REQUEST);
            } else if (e.getMessage() != null && e.getMessage().contains("emailId")) {
                logger.debug(String.format("User : %s registration failed. Email-Id not unique. Returning response with status 400:BAD_REQUEST", user.getUserName()));
                return new ResponseEntity<>(new ResponseMessage("EmailId is not unique"), HttpStatus.BAD_REQUEST);
            } else {
                logger.debug(String.format("User : %s registration failed. Returning response with status 500:INTERNAL_SERVER_ERROR", user.getUserName()));
                logger.debug("Error Message : " + e.getMessage());
                return new ResponseEntity<>(new ResponseMessage("Internal error occured"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            logger.debug(String.format("User : %s registration failed. Returning response with status 500:INTERNAL_SERVER_ERROR", user.getUserName()));
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Internal error occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/users/all")
    public ResponseEntity<?> getAllUsers() {
        try {
            logger.debug("Request received inside AuthenticationServiceController for fetching all registered users");
            List<UserDetails> userDetailsList = authenticationService.getAllUsers();
            logger.debug("All registered users fetched successfully. Returning response with status 200:OK");
            return new ResponseEntity<>(userDetailsList, HttpStatus.OK);
        } catch (Exception e) {
            logger.debug("Fetching all registered users failed. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Internal Error Occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/user/search/{username}")
    public ResponseEntity<?> searchByUserName(@PathVariable("username") String userName) {
        try {
            logger.debug(String.format("Request received inside AuthenticationServiceController for searching user containing substring %s in username", userName));
            List<UserDetails> userDetailsList = authenticationService.searchByUserName(userName);
            logger.debug("UserDetails fetched successfully. Returning response with status 200:OK");
            return new ResponseEntity<>(userDetailsList, HttpStatus.OK);
        } catch (UsernameNotFoundException e) {
            logger.debug("No users found satisfying the criteria. Returning response with status 400:BAD_REQUEST");
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.debug("UserDetails fetching failed. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Internal Error Occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/{username}/forgot")
    public ResponseEntity<ResponseMessage> forgotPassword(@PathVariable("username") String userName, @RequestBody String emailId) {
        try {
            logger.debug("Request received inside AuthenticationServiceController for generating OTP for user : " + userName);
            Boolean isValid = authenticationService.forgotPassword(userName, emailId);
            if (isValid) {
                logger.debug("Returning response with status 201:CREATED");
                return new ResponseEntity<>(new ResponseMessage("OTP sent successfully"), HttpStatus.CREATED);
            } else {
                logger.debug("Error occurred. Returning response with status 500:INTERNAL_SERVER_ERROR");
                return new ResponseEntity<>(new ResponseMessage("Internal error occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (MessagingException e) {
            logger.debug("Messaging Error Occurred. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (UsernameNotFoundException | UnregisteredEmailIdException e) {
            logger.debug("Error occurred. Returning response with status 400:BAD_REQUEST");
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.debug("Internal Error Occurred. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Internal Error Occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{username}/{otp}/verifyOtp")
    public ResponseEntity<ResponseMessage> verifyOtp(@PathVariable("username") String userName, @PathVariable("otp") String otp) {
        try {
            logger.debug("Request received inside AuthenticationServiceController for verifying OTP for user : " + userName);
            if (authenticationService.verifyOtp(userName, otp)) {
                logger.debug("Returning response with status 200:OK");
                return new ResponseEntity<>(new ResponseMessage("OTP validated successfully"), HttpStatus.OK);
            } else {
                logger.debug("Returning response with status 400:BAD_REQUEST");
                return new ResponseEntity<>(new ResponseMessage("Invalid OTP"), HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            logger.debug("Internal Error Occurred. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Internal Error Occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{username}/reset")
    public ResponseEntity<ResponseMessage> resetPassword(@PathVariable("username") String userName, @RequestBody String newPassword) {
        try {
            logger.debug("Request received inside AuthenticationServiceController for resetting password for user : " + userName);
            authenticationService.resetPassword(userName, newPassword);
            logger.debug("Returning response with status 200:OK");
            return new ResponseEntity<>(new ResponseMessage("Password reset successful"), HttpStatus.OK);
        } catch (UsernameNotFoundException e) {
            logger.debug("Returning response with status 400:BAD_REQUEST");
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.debug("Internal Error Occurred. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Internal Error Occurred"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
