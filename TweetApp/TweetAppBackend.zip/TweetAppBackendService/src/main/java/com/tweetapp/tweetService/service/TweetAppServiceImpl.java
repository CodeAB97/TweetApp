package com.tweetapp.tweetService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.tweetService.exception.InvalidTweetIdException;
import com.tweetapp.tweetService.model.Tweet;
import com.tweetapp.tweetService.model.TweetReplies;
import com.tweetapp.tweetService.repository.TweetsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class TweetAppServiceImpl implements TweetAppService {

    private final Logger logger = LoggerFactory.getLogger(TweetAppServiceImpl.class);

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private TweetsRepository tweetsRepository;

    @Override
    public void postTweet(String username, Tweet tweet) throws JsonProcessingException {
        tweet.setTime(new Date());
        tweet.setTweetReplies(List.of());
        tweet.setUserName(username);
        tweet.setLikes(List.of());
        logger.debug("Posting tweet. Saving tweet data in the database : " + objectMapper.writeValueAsString(tweet));
        tweetsRepository.save(tweet);
    }

    @Override
    public List<Tweet> fetchAllTweets() throws JsonProcessingException {
        logger.debug("Fetching all tweets from the database");
        List<Tweet> tweetList = tweetsRepository.findAll();
        logger.debug("Tweets fetched : " + objectMapper.writeValueAsString(tweetList));
        for (Tweet tweet : tweetList) {
            Collections.sort(tweet.getTweetReplies());
        }
        Collections.sort(tweetList);
        logger.debug("Sorting of tweet replies and tweet-list successful");
        return tweetList;
    }

    @Override
    public List<Tweet> fetchAllTweetByUserName(String userName) throws JsonProcessingException {
        logger.debug(String.format("Fetching all tweets of user : %s from database", userName));
        List<Tweet> tweetListByUser = tweetsRepository.findByUserName(userName);
        logger.debug("Tweets fetched : " + objectMapper.writeValueAsString(tweetListByUser));
        for (Tweet tweet : tweetListByUser) {
            Collections.sort(tweet.getTweetReplies());
        }
        Collections.sort(tweetListByUser);
        logger.debug("Sorting of tweet replies and tweet-list successful");
        return tweetListByUser;
    }

    @Override
    public void updateTweetById(String id, String updatedTweetText) throws JsonProcessingException {
        logger.debug(String.format("Fetching tweet by id : %s from the database", id));
        Optional<Tweet> originalTweet = tweetsRepository.findById(id);
        if (originalTweet.isPresent()) {
            logger.debug("Tweet fetching successful : " + objectMapper.writeValueAsString(originalTweet));
            logger.debug("Updating tweet now...");
            Tweet updatedTweet = originalTweet.get();
            updatedTweet.setTweetText(updatedTweetText);
            tweetsRepository.save(updatedTweet);
            logger.debug("Tweet updated successfully with updated_tweet_text : " + updatedTweetText);
        } else {
            logger.debug(String.format("Tweet fetching failed. Tweet with id : %s not present in the database", id));
            throw new InvalidTweetIdException("Tweet not found");
        }
    }

    @Override
    public void deleteTweetById(String id) throws JsonProcessingException {
        logger.debug(String.format("Fetching tweet by id : %s from the database", id));
        Optional<Tweet> originalTweet = tweetsRepository.findById(id);
        if (originalTweet.isPresent()) {
            logger.debug("Tweet fetching successful : " + objectMapper.writeValueAsString(originalTweet));
            logger.debug("Deleting tweet now...");
            tweetsRepository.deleteById(id);
            logger.debug("Tweet deleted successfully");
        } else {
            logger.debug(String.format("Tweet fetching failed. Tweet with id : %s not present in the database", id));
            throw new InvalidTweetIdException("Tweet not found");
        }
    }

    @Override
    public void likeTweetById(String userName, String id) throws JsonProcessingException {
        logger.debug(String.format("Fetching tweet by id : %s from the database", id));
        Optional<Tweet> originalTweet = tweetsRepository.findById(id);
        if (originalTweet.isPresent()) {
            logger.debug("Tweet fetching successful : " + objectMapper.writeValueAsString(originalTweet));
            logger.debug("Liking tweet now...");
            Tweet updatedLikeTweet = originalTweet.get();
            if (updatedLikeTweet.getLikes().contains(userName)) {
                updatedLikeTweet.getLikes().remove(userName);
            } else {
                updatedLikeTweet.getLikes().add(userName);
            }
            tweetsRepository.save(updatedLikeTweet);
            logger.debug("Tweet liked successfully");
        } else {
            logger.debug(String.format("Tweet fetching failed. Tweet with id : %s not present in the database", id));
            throw new InvalidTweetIdException("Tweet not found");
        }
    }

    @Override
    public void replyOnTweetById(String username, String id, String replyText) throws JsonProcessingException {
        logger.debug(String.format("Fetching tweet by id : %s from the database", id));
        Optional<Tweet> originalTweet = tweetsRepository.findById(id);
        if (originalTweet.isPresent()) {
            logger.debug("Tweet fetching successful : " + objectMapper.writeValueAsString(originalTweet));
            logger.debug("Replying on tweet now...");
            TweetReplies tweetReplies = TweetReplies.builder().userName(username).time(new Date()).replyText(replyText).build();
            Tweet updatedTweetReplies = originalTweet.get();
            List<TweetReplies> tweetReplyList = updatedTweetReplies.getTweetReplies();
            tweetReplyList.add(tweetReplies);
            updatedTweetReplies.setTweetReplies(tweetReplyList);
            tweetsRepository.save(updatedTweetReplies);
            logger.debug("Replying on tweet successful");
        } else {
            logger.debug(String.format("Tweet fetching failed. Tweet with id : %s not present in the database", id));
            throw new InvalidTweetIdException("Tweet not found");
        }
    }

}
