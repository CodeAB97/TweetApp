package com.tweetapp.tweetService.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Builder;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TweetReplies implements Comparable<TweetReplies> {

    private String userName;
    private Date time;
    private String replyText;

    @Override
    public int compareTo(TweetReplies o) {
        if (time.before(o.getTime())) {
            return 1;
        } else if (time.after(o.getTime())) {
            return -1;
        }
        return 0;
    }

}
