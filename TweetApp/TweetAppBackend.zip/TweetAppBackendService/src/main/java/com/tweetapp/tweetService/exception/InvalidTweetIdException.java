package com.tweetapp.tweetService.exception;

public class InvalidTweetIdException extends RuntimeException {

    public InvalidTweetIdException(String message) {
        super(message);
    }

}
