package com.tweetapp.authenticationService.service.jwtService.service;

import com.tweetapp.authenticationService.model.User;
import com.tweetapp.authenticationService.service.AuthenticationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AuthenticationManagerImpl implements AuthenticationManager {

    private final Logger logger = LoggerFactory.getLogger(AuthenticationManagerImpl.class);

    @Autowired
    public AuthenticationService authenticationService;

    @Autowired
    public PasswordEncoder passwordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        logger.debug(String.format("Validating user credentials of user : %s if it is registered in the database", authentication.getPrincipal().toString()));
        User user = authenticationService.fetchUserByUsername(authentication.getPrincipal().toString());
        if (user != null && passwordEncoder.matches(authentication.getCredentials().toString(), user.getPassword())) {
            logger.debug("Validation of user credentials successful");
            Map<String, String> userDetails = new HashMap<>();
            userDetails.put("FIRST_NAME", user.getFirstName());
            userDetails.put("LAST_NAME", user.getLastName());
            return new UsernamePasswordAuthenticationToken(user, userDetails);
        } else if (user == null) {
            logger.debug("Validation of user credentials failed : Username is not registered");
            throw new BadCredentialsException("Username not registered");
        } else {
            logger.debug("Validation of user credentials failed : Password is incorrect");
            throw new BadCredentialsException("Password is incorrect");
        }
    }

}
