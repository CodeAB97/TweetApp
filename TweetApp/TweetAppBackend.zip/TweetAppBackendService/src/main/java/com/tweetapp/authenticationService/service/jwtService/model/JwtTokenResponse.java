package com.tweetapp.authenticationService.service.jwtService.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
public class JwtTokenResponse implements Serializable {

    private final String token;
    private Map<String, String> userDetails;

}
