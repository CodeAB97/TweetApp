package com.tweetapp.authenticationService.service.jwtService.utility;

import com.tweetapp.authenticationService.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Clock;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.DefaultClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Date;
import java.util.function.Function;

@Component
public class JwtTokenUtil implements Serializable {

    private final Logger logger = LoggerFactory.getLogger(JwtTokenUtil.class);

    private Clock clock = DefaultClock.INSTANCE;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Value("${jwt.signing.key.secret}")
    private String secret;

    @Value("${jwt.token.expiration.in.seconds}")
    private Long expiration;

    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public String getIdFromToken(String token) {
        return getClaimFromToken(token, Claims::getId);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
    }

    private Boolean isTokenExpired(String token) {
        logger.debug("Checking if JWT-Token is expired");
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(clock.now());
    }

    public String generateToken(Authentication authenticatedUser) {
        logger.debug("Inside generateToken() method of JwtTokenUtil class");
        final Date createdDate = clock.now();
        final Date expirationDate = calculateExpirationDate(createdDate);
        User subject = (User) authenticatedUser.getPrincipal();
        String encodedSubjectId = passwordEncoder.encode(subject.getId());
        return Jwts.builder().setSubject(subject.getUserName()).setIssuedAt(createdDate)
                .setExpiration(expirationDate).signWith(SignatureAlgorithm.HS512, secret).setId(encodedSubjectId).compact();
    }

    public Boolean validateToken(String token, User user) {
        logger.debug("Validating JWT-Token");
        final String username = getUsernameFromToken(token);
        final String encodedSubjectId = getIdFromToken(token);
        return (username.equals(user.getUserName()) && encodedSubjectId != null && passwordEncoder.matches(user.getId(), encodedSubjectId) && !isTokenExpired(token));
    }

    private Date calculateExpirationDate(Date createdDate) {
        logger.debug("Calculating expiration date for JWT-Token");
        return new Date(createdDate.getTime() + expiration * 1000);
    }

}
