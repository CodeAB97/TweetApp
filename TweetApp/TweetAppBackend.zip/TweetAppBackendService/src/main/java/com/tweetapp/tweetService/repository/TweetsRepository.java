package com.tweetapp.tweetService.repository;

import com.tweetapp.tweetService.model.Tweet;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TweetsRepository extends MongoRepository<Tweet, String> {

    List<Tweet> findByUserName(String userName);

}
