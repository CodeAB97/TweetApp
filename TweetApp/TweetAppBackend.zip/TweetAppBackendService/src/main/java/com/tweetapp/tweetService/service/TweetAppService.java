package com.tweetapp.tweetService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tweetapp.tweetService.model.Tweet;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TweetAppService {

    void postTweet(String username, Tweet tweet) throws JsonProcessingException;

    List<Tweet> fetchAllTweets() throws JsonProcessingException;

    List<Tweet> fetchAllTweetByUserName(String userName) throws JsonProcessingException;

    void updateTweetById(String id, String updatedTweetText) throws JsonProcessingException;

    void deleteTweetById(String id) throws JsonProcessingException;

    void likeTweetById(String userName, String id) throws JsonProcessingException;

    void replyOnTweetById(String username, String id, String replyText) throws JsonProcessingException;

}
