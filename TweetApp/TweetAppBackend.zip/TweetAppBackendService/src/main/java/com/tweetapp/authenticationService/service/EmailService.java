package com.tweetapp.authenticationService.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

@Service
public class EmailService {

    private final Logger logger = LoggerFactory.getLogger(EmailService.class);

    public boolean sendEmail(String message, String to) throws MessagingException {
        boolean isMailSent = Boolean.FALSE;
        String host = "smtp.gmail.com";
        String from = "hsinghfse1@gmail.com";
        String subject = "TweetApp Password Reset OTP";
        logger.debug("Setting smtp properties");
        Properties properties = System.getProperties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("hsinghfse1@gmail.com", "zdksalfcibawssbb");
            }
        });
        logger.debug("Session object created for sending email");
        MimeMessage mimeMessage = new MimeMessage(session);
        mimeMessage.setFrom(from);
        mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
        mimeMessage.setSubject(subject);
        mimeMessage.setContent(message, "text/html");
        logger.debug("MimeMessage object created. Now sending email...");
        Transport.send(mimeMessage);
        isMailSent = Boolean.TRUE;
        return isMailSent;
    }

}
