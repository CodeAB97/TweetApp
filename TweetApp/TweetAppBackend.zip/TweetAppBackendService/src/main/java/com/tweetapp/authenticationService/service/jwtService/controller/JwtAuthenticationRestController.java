package com.tweetapp.authenticationService.service.jwtService.controller;

import com.tweetapp.authenticationService.service.jwtService.utility.JwtTokenUtil;
import com.tweetapp.authenticationService.service.jwtService.model.JwtTokenRequest;
import com.tweetapp.authenticationService.service.jwtService.model.JwtTokenResponse;
import com.tweetapp.authenticationService.service.jwtService.exception.AuthenticationException;
import com.tweetapp.authenticationService.service.jwtService.service.JwtAuthenticationService;
import com.tweetapp.authenticationService.model.ResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1.0/tweets")
@CrossOrigin(origins = "*")
public class JwtAuthenticationRestController {

    private final Logger logger = LoggerFactory.getLogger(JwtAuthenticationRestController.class);

    @Value("${jwt.http.request.header}")
    private String tokenHeader;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private JwtAuthenticationService jwtAuthenticationService;

    @PostMapping("/login")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtTokenRequest authenticationRequest) {
        try {
            logger.debug("Request received inside JwtAuthenticationRestController for logging in user : " + authenticationRequest.getUserName());
            Authentication authenticatedUser = jwtAuthenticationService.authenticate(authenticationRequest.getUserName(), authenticationRequest.getPassword());
            logger.debug("User authenticated successfully. Now generating JWT-Token...");
            final String token = jwtTokenUtil.generateToken(authenticatedUser);
            logger.debug("JWT-Token generated successfully. Returning response with status 201:CREATED");
            return new ResponseEntity<>(new JwtTokenResponse(token, (Map<String, String>) authenticatedUser.getCredentials()), HttpStatus.CREATED);
        } catch (AuthenticationException e) {
            logger.debug("Error occurred. Returning response with status 401:UNAUTHORIZED");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new ResponseMessage(e.getMessage()));
        } catch (Exception e) {
            logger.debug("Internal Error Occurred. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>("Internal error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}