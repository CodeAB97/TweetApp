package com.tweetapp.authenticationService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.authenticationService.exception.UnregisteredEmailIdException;
import com.tweetapp.authenticationService.model.User;
import com.tweetapp.authenticationService.model.UserDetails;
import com.tweetapp.authenticationService.repository.UserRepository;
import com.tweetapp.authenticationService.service.kafkaService.ProducerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.util.*;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    private final Logger logger = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${spring.kafka.topic.name}")
    private String topicName;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private ProducerService producerService;

    @Autowired
    public PasswordEncoder passwordEncoder;

    private Map<String, String> otpData = new HashMap<>();

    private Random random = new Random(1000);

    @Override
    public void registerUser(User user) throws JsonProcessingException {
        logger.debug("Encoding password before saving in the database");
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        logger.debug("Registering user with details : " + objectMapper.writeValueAsString(user));
        userRepository.save(user);
    }

    @Override
    public User fetchUserByUsername(String userName) {
        logger.debug("Fetching user details with username : " + userName);
        return userRepository.findByUserName(userName);
    }

    @Override
    public List<UserDetails> getAllUsers() throws JsonProcessingException {
        logger.debug("Fetching all registered users from the database");
        List<User> users = userRepository.findAll();
        List<UserDetails> userDetailsList = new ArrayList<>();
        for (User user : users) {
            UserDetails userDetails = UserDetails.builder().userName(user.getUserName()).firstName(user.getFirstName()).lastName(user.getLastName()).build();
            userDetailsList.add(userDetails);
        }
        logger.debug("UserList fetched : " + objectMapper.writeValueAsString(userDetailsList));
        return userDetailsList;
    }

    @Override
    public List<UserDetails> searchByUserName(String userName) throws JsonProcessingException {
        logger.debug(String.format("Fetching details of registered user(s) containing substring %s in their username from the database", userName));
        List<User> users = userRepository.findAll();
        List<UserDetails> userDetailsList = new ArrayList<>();
        for (User user : users) {
            if (user.getUserName().contains(userName)) {
                UserDetails userDetails = UserDetails.builder().userName(user.getUserName()).firstName(user.getFirstName()).lastName(user.getLastName()).build();
                userDetailsList.add(userDetails);
            }
        }
        if (userDetailsList.isEmpty()) {
            logger.debug(String.format("No registered user(s) found with username containing substring %s in the database", userName));
            throw new UsernameNotFoundException("Username doesn't exists");
        }
        logger.debug("UserDetailsList fetched : " + objectMapper.writeValueAsString(userDetailsList));
        return userDetailsList;
    }

    @Override
    public Boolean forgotPassword(String userName, String emailId) throws MessagingException {
        logger.debug(String.format("Validating user : %s if it is registered in the database", userName));
        User user = userRepository.findByUserName(userName);
        if (user != null) {
            logger.debug(String.format("User validation successful. Now validating if email-id : %s provided in request payload is same as registered email-id", emailId));
            if (user.getEmailId().equals(emailId)) {
                logger.debug("Email-Id validation successful. Generating OTP...");
                int otp = random.ints(100000, 1000000).findFirst().getAsInt();
                String message = "<h1>OTP = " + otp + "</h1>";
                String eventMessage = userName + ":" + otp;
                logger.debug(String.format("Sending message : %s to kafka producer service", eventMessage));
                if (producerService.sendMessage(eventMessage)) {
                    logger.debug(String.format("Message sent to kafka producer successfully. Now sending OTP : %s to email-id : %s", otp, emailId));
                    if (emailService.sendEmail(message, emailId)) {
                        logger.debug("OTP sent successfully via email");
                        return Boolean.TRUE;
                    } else {
                        logger.debug("Failed to send OTP via email");
                        return Boolean.FALSE;
                    }
                } else {
                    logger.debug("Failed to write message to kafka topic : " + topicName);
                    return Boolean.FALSE;
                }
            } else {
                logger.debug("Email-Id validation failed. Email-Id not registered with user");
                throw new UnregisteredEmailIdException("Email-id not registered");
            }
        } else {
            logger.debug("User validation failed. Username not registered in the database");
            throw new UsernameNotFoundException("Username doesn't exists");
        }
    }

    @Override
    public void updateOtpData(String eventMessage) {
        if (Objects.nonNull(eventMessage)) {
            logger.debug("Updating OTP data stored in memory");
            String[] otpDetails = eventMessage.split(":");
            if (otpDetails.length == 2) {
                if (otpData.size() > 0) {
                    if (otpData.containsKey(otpDetails[0])) {
                        otpData.replace(otpDetails[0], otpDetails[1]);
                        logger.debug("OTP data updated successfully");
                    } else {
                        otpData.put(otpDetails[0], otpDetails[1]);
                        logger.debug("OTP data updated successfully");
                    }
                } else {
                    otpData.put(otpDetails[0], otpDetails[1]);
                    logger.debug("OTP data updated successfully");
                }
            } else {
                logger.debug(String.format("Failed to update OTP data. EventMessage : %s received is not having the valid format 'username:otp'." + eventMessage));
                throw new RuntimeException();
            }
        } else {
            logger.debug("Failed to update OTP data. EventMessage received is null");
            throw new RuntimeException();
        }
    }

    @Override
    public Boolean verifyOtp(String userName, String otp) {
        logger.debug("Verifying OTP : " + otp);
        if (otpData.get(userName).equals(otp)) {
            otpData.remove(userName);
            logger.debug("OTP verification successful");
            return Boolean.TRUE;
        } else {
            logger.debug("OTP verification failed. OTP is invalid");
            return Boolean.FALSE;
        }
    }

    @Override
    public void resetPassword(String userName, String newPassword) {
        logger.debug(String.format("Validating user : %s if it is registered in the database", userName));
        User user = userRepository.findByUserName(userName);
        if (user != null) {
            logger.debug("User validation successful. Now changing password...");
            String encodedPassword = passwordEncoder.encode(newPassword);
            user.setPassword(encodedPassword);
            userRepository.save(user);
            logger.debug("Password reset successful");
        } else {
            logger.debug("User validation failed. Username not registered in the database");
            throw new UsernameNotFoundException("Username doesn't exists");
        }
    }

}
