package com.tweetapp.tweetService.controller;

import com.tweetapp.authenticationService.model.ResponseMessage;
import com.tweetapp.tweetService.exception.InvalidTweetIdException;
import com.tweetapp.tweetService.model.Tweet;
import com.tweetapp.tweetService.service.TweetAppService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/tweets")
@CrossOrigin(origins = "*")
public class TweetingServiceController {

    private final Logger logger = LoggerFactory.getLogger(TweetingServiceController.class);

    @Autowired
    TweetAppService tweetAppService;

    @PostMapping("/{username}/add")
    public ResponseEntity<ResponseMessage> postTweeet(@PathVariable("username") String userName, @RequestBody Tweet tweet) {
        try {
            logger.debug("Request received inside TweetingServiceController for posting tweet by user : " + userName);
            tweetAppService.postTweet(userName, tweet);
            logger.debug("Tweet Posting successful. Returning response with status 201:CREATED");
            return new ResponseEntity<>(new ResponseMessage("Tweet Posting Successful"), HttpStatus.CREATED);
        } catch (Exception e) {
            logger.debug("Tweet Posting failed. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Tweet posting failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllTweets() {
        try {
            logger.debug("Request received inside TweetingServiceController for fetching all tweets");
            List<Tweet> tweetList = tweetAppService.fetchAllTweets();
            logger.debug("All tweets fetched successfully. Returning response with status 200:OK");
            return new ResponseEntity<>(tweetList, HttpStatus.OK);
        } catch (Exception e) {
            logger.debug("Fetching all tweets failed. Returning response with status 500:INTERNAL_SERVER_ERROR");
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Tweet fetching failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{username}")
    public ResponseEntity<?> getAllTweetsByUserName(@PathVariable("username") String userName) {
        try {
            logger.debug("Request received inside TweetingServiceController for fetching all tweets by user : " + userName);
            List<Tweet> tweetList = tweetAppService.fetchAllTweetByUserName(userName);
            logger.debug(String.format("All tweets of user : %s fetched successfully. Returning response with status 200:OK", userName));
            return new ResponseEntity<>(tweetList, HttpStatus.OK);
        } catch (Exception e) {
            logger.debug(String.format("Fetching All tweets of user : %s failed. Returning response with status 500:INTERNAL_SERVER_ERROR", userName));
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Tweet fetching failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("{username}/update/{id}")
    public ResponseEntity<ResponseMessage> updateTweet(@PathVariable("username") String userName, @PathVariable("id") String id, @RequestBody String updatedTweetText) {
        try {
            logger.debug("Request received inside TweetingServiceController for updating tweet with id : " + id);
            tweetAppService.updateTweetById(id, updatedTweetText);
            logger.debug(String.format("Tweet with id : %s updated successfully. Returning response with status 200:OK", id));
            return new ResponseEntity<>(new ResponseMessage("Tweet Update Successful"), HttpStatus.OK);
        } catch (InvalidTweetIdException e) {
            logger.debug(String.format("Updating tweet with id: %s failed. Returning response with status 404:NOT_FOUND", id));
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.debug(String.format("Updating tweet with id: %s failed. Returning response with status 500:INTERNAL_SERVER_ERROR", id));
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Tweet Update Failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("{username}/delete/{id}")
    public ResponseEntity<ResponseMessage> deleteTweet(@PathVariable("username") String userName, @PathVariable("id") String id) {
        try {
            logger.debug("Request received inside TweetingServiceController for deleting tweet with id : " + id);
            tweetAppService.deleteTweetById(id);
            logger.debug(String.format("Tweet with id : %s deleted successfully. Returning response with status 200:OK", id));
            return new ResponseEntity<>(new ResponseMessage("Tweet Deletion Successful"), HttpStatus.OK);
        } catch (InvalidTweetIdException e) {
            logger.debug(String.format("Deleting tweet with id: %s failed. Returning response with status 404:NOT_FOUND", id));
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.debug(String.format("Deleting tweet with id: %s failed. Returning response with status 500:INTERNAL_SERVER_ERROR", id));
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Tweet Deletion Failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("{username}/like/{id}")
    public ResponseEntity<ResponseMessage> likeTweet(@PathVariable("username") String userName, @PathVariable("id") String id) {
        try {
            logger.debug("Request received inside TweetingServiceController for like tweet with id : " + id);
            tweetAppService.likeTweetById(userName, id);
            logger.debug(String.format("Tweet with id : %s liked successfully by user : %s. Returning response with status 200:OK", id, userName));
            return new ResponseEntity<>(new ResponseMessage("Tweet Like Successful"), HttpStatus.OK);
        } catch (InvalidTweetIdException e) {
            logger.debug(String.format("Like tweet with id: %s failed. Returning response with status 404:NOT_FOUND", id));
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.debug(String.format("Like tweet with id: %s failed. Returning response with status 500:INTERNAL_SERVER_ERROR", id));
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Tweet Like Failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("{username}/reply/{id}")
    public ResponseEntity<ResponseMessage> replyOnTweet(@PathVariable("username") String userName, @PathVariable("id") String id, @RequestBody String replyText) {
        try {
            logger.debug("Request received inside TweetingServiceController for replying on tweet with id : " + id);
            tweetAppService.replyOnTweetById(userName, id, replyText);
            logger.debug(String.format("Replying on tweet with id : %s by user : %s successful. Returning response with status 200:OK", id, userName));
            return new ResponseEntity<>(new ResponseMessage("Replying on Tweet Successful"), HttpStatus.OK);
        } catch (InvalidTweetIdException e) {
            logger.debug(String.format("Reply on tweet with id: %s failed. Returning response with status 404:NOT_FOUND", id));
            return new ResponseEntity<>(new ResponseMessage(e.getMessage()), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.debug(String.format("Reply on tweet with id: %s failed. Returning response with status 500:INTERNAL_SERVER_ERROR", id));
            logger.debug("Error Message : " + e.getMessage());
            return new ResponseEntity<>(new ResponseMessage("Replying on Tweet Failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
