package com.tweetapp.authenticationService.service.kafkaService;

import com.tweetapp.authenticationService.service.AuthenticationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService {

    private final Logger logger = LoggerFactory.getLogger(ConsumerService.class);

    @Autowired
    private AuthenticationService authenticationService;

    @KafkaListener(
            topics = "${spring.kafka.topic.name}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consume(String eventMessage) {
        logger.debug("Message successfully received in kafka consumer. Now calling updateOtpData() method to update OTP data");
        authenticationService.updateOtpData(eventMessage);
    }

}
