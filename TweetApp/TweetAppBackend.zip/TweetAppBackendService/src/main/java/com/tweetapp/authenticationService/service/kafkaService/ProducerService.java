package com.tweetapp.authenticationService.service.kafkaService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.SettableListenableFuture;

@Service
public class ProducerService {

    private final Logger logger = LoggerFactory.getLogger(ProducerService.class);

    @Value("${spring.kafka.topic.name}")
    private String topicName;

    private KafkaTemplate<String, String> kafkaTemplate;

    public ProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public boolean sendMessage(String eventMessage) {
        logger.debug(String.format("Writing message : %s to kafka topic : %s", eventMessage, topicName));
        SettableListenableFuture future = (SettableListenableFuture) kafkaTemplate.send(topicName, eventMessage);
        return !(future.isCancelled());
    }

}
