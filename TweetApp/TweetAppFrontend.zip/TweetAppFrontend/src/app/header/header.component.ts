import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtAuthenticationService } from '../service/jwtAuthenticationService/jwt-authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(public jwtAuthenticationService: JwtAuthenticationService, private router: Router) { }

  ngOnInit(): void {
  }

  logout() {
    this.jwtAuthenticationService.logoutUser()
    this.router.navigate(['login'])
  }

}
