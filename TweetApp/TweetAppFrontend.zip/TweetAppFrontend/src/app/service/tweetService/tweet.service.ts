import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URL, USER_NAME } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class TweetService {

  userName: any

  constructor(private httpClient: HttpClient) { }

  postTweet(tweet: any) {
    this.userName = sessionStorage.getItem(USER_NAME)
    return this.httpClient.post<any>(`http://${URL}/api/v1.0/tweets/${this.userName}/add`, tweet)
  }

  getAllTweets() {
    return this.httpClient.get<any>(`http://${URL}/api/v1.0/tweets/all`)
  }

  likeUnlikeTweet(userName: any, id: string) {
    return this.httpClient.put<any>(`http://${URL}/api/v1.0/tweets/${userName}/like/${id}`, null)
  }

  updateTweet(userName: any, id: string, updatedTweetText: string) {
    return this.httpClient.put<any>(`http://${URL}/api/v1.0/tweets/${userName}/update/${id}`, updatedTweetText)
  }

  deleteTweet(userName: any, id: string) {
    return this.httpClient.delete<any>(`http://${URL}/api/v1.0/tweets/${userName}/delete/${id}`)
  }

  replyOnTweet(userName:any, id: string, replyText: string) {
    return this.httpClient.post<any>(`http://${URL}/api/v1.0/tweets/${userName}/reply/${id}`, replyText)
  }

  getAllTweetsOfUser(userName: string) {
    return this.httpClient.get<any>(`http://${URL}/api/v1.0/tweets/${userName}`)
  }

  setPostTime(response: any) {
    for(let tweet of response) {
      tweet.time = this.getPostTime(tweet.time)
      if(tweet.tweetReplies.length) {
        for(let reply of tweet.tweetReplies) {
          reply.time = this.getPostTime(reply.time)
        }
      }
    }
    return response
  }

  getPostTime(time: any) {
    let tweetDate = new Date(time)
    let currentDate = new Date()
    let tweetDateInSeconds = tweetDate.getTime()/1000;
    let currentDateInSeconds = currentDate.getTime()/1000;
    let tweetSeconds = Math.abs(tweetDateInSeconds - currentDateInSeconds)
    if(tweetSeconds < 60) {
      return Math.floor(tweetSeconds) + ' seconds ago'
    } else if(tweetSeconds < 3600) {
      return Math.floor(tweetSeconds/60) + ' minutes ago'
    } else if(tweetSeconds < 86400) {
      return Math.floor(tweetSeconds/3600) + ' hours ago'
    } else {
      return tweetDate.toDateString();
    }
  }

  processMessage(message: string) {
      let subMessage = message.split('#')
      for(let i=1; i<subMessage.length; i++) {
        if(subMessage[i].length > 50) {
          return false;
        }
      }
      return true
  }
  
}
