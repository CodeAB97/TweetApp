import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URL } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) { }

  getAllUsers() {
    return this.httpClient.get(`http://${URL}/api/v1.0/tweets/users/all`)
  }

  searchByUserName(userName: any) {
    return this.httpClient.get(`http://${URL}/api/v1.0/tweets/user/search/${userName}`)
  }

  registerUser(registrationData: Object) {
    return this.httpClient.post<any>(`http://${URL}/api/v1.0/tweets/register`, registrationData)
  }

}
