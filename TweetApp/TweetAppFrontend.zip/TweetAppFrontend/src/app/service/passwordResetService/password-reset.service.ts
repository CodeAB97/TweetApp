import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { URL } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class PasswordResetService {

  constructor(private httpClient: HttpClient) { }

  getOtp(userDetails: any) {
    return this.httpClient.post(`http://${URL}/api/v1.0/tweets/${userDetails.userName}/forgot`, userDetails.emailId)
  }

  verifyOtp(userName: any, otp: string) {
    return this.httpClient.get(`http://${URL}/api/v1.0/tweets/${userName}/${otp}/verifyOtp`)
  }

  resetPassword(userName: any, newPassword: string) {
    return this.httpClient.put(`http://${URL}/api/v1.0/tweets/${userName}/reset`, newPassword)
  }

}
