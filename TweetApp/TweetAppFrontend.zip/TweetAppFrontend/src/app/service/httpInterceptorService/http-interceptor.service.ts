import { HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtAuthenticationService } from '../jwtAuthenticationService/jwt-authentication.service';

@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorService implements HttpInterceptor {

  constructor(private jwtAuthenticationService: JwtAuthenticationService) { }

  intercept(request: HttpRequest<any>, httpHandler: HttpHandler) {
    let jwtAuthenticationHeader = this.jwtAuthenticationService.getAuthenticationToken()
    if(jwtAuthenticationHeader) {
      request = request.clone({
        setHeaders: {
          Authorization: jwtAuthenticationHeader
        }
      })
    }
    return httpHandler.handle(request)
  }

}
