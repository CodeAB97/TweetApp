import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { FIRST_NAME, LAST_NAME, TOKEN, URL, USER_NAME } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class JwtAuthenticationService {

  constructor(private httpClient: HttpClient) { }

  authenticateUser(userCredentials: any) {
    return this.httpClient.post<any>(`http://${URL}/api/v1.0/tweets/login`, userCredentials).pipe(
      map(
        data => {
          sessionStorage.setItem(USER_NAME, userCredentials.userName)
          sessionStorage.setItem(FIRST_NAME, data.userDetails.FIRST_NAME)
          sessionStorage.setItem(LAST_NAME, data.userDetails.LAST_NAME)
          sessionStorage.setItem(TOKEN, `Bearer ${data.token}`)
          return data
        }
      )
    )
  }

  getAuthenticationToken() {
    return sessionStorage.getItem(TOKEN)
  }

  getAuthenticatedUser() {
    return sessionStorage.getItem(USER_NAME)
  }

  isUserLoggedIn() {
    let userName = sessionStorage.getItem(USER_NAME)
    return !(userName === null)
  }

  logoutUser() {
    sessionStorage.clear()
  }

}
