import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OTP_USER } from '../app.constants';
import { PasswordResetService } from '../service/passwordResetService/password-reset.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  usernameErrorFlag = false
  emailErrorFlag = false
  otpErrorFlag = false
  passwordMatchFlag = true
  showUserDetailsForm = true
  showSubmitOtpForm = false
  showSuccessMessage = false
  showResetPasswordForm = false
  usernameErrorMessage = "Username doesn't exists"
  emailErrorMessage = 'Email-id not registered'
  otpErrorMessage = 'Invalid OTP'

  userDetails = {
    userName: '',
    emailId: ''
  }

  password = {
    newPassword: '',
    cnfmpassword: ''
  }

  otp: any

  constructor(private passwordResetService: PasswordResetService, private router: Router) { }

  ngOnInit(): void {
  }

  getOtp() {
    this.passwordResetService.getOtp(this.userDetails).subscribe(
      response => this.handleSuccesfulOTPGeneration(response),
      error => this.handleUnsuccesfulOTPGeneration(error)
    )
  }

  handleSuccesfulOTPGeneration(response: any) {
    this.showUserDetailsForm = false
    this.showSubmitOtpForm = true
    sessionStorage.setItem(OTP_USER, this.userDetails.userName)
  }

  handleUnsuccesfulOTPGeneration(error: HttpErrorResponse) {
    if(error.error.message === this.usernameErrorMessage) {
      this.usernameErrorFlag = true
    } else if(error.error.message === this.emailErrorMessage) {
      this.emailErrorFlag = true
    } else {
      this.router.navigate(['error'])
    }
  }

  submitOtp() {
    let userName = sessionStorage.getItem(OTP_USER)
    this.passwordResetService.verifyOtp(userName, this.otp).subscribe(
      response => this.handleSuccesfulOTPVerification(response),
      error => this.handleUnsuccesfulOTPVerification(error)
    )
  }

  handleSuccesfulOTPVerification(response: any) {
    this.showSubmitOtpForm = false
    this.showResetPasswordForm = true
  }

  handleUnsuccesfulOTPVerification(error: HttpErrorResponse) {
    if(error.error.message === this.otpErrorMessage) {
      this.otpErrorFlag = true
    } else {
      this.router.navigate(['error'])
    }
  }

  resetPassword() {
    if(this.password.newPassword === this.password.cnfmpassword) {
      let userName = sessionStorage.getItem(OTP_USER)
      this.passwordResetService.resetPassword(userName, this.password.newPassword).subscribe(
        response => this.handleSuccesfulPasswordReset(),
        error => this.handleUnsuccesfulPasswordReset(error)
      )
    } else {
      this.passwordMatchFlag = false
    }
  }

  handleSuccesfulPasswordReset() {
    this.showSuccessMessage = true
    this.showResetPasswordForm = false
  }

  handleUnsuccesfulPasswordReset(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  clearFlags() {
    this.usernameErrorFlag = false
    this.emailErrorFlag = false
  }

  clearOtpErrorFlag() {
    this.otpErrorFlag = false
  }

  clearPasswordMatchFlag() {
    this.passwordMatchFlag = true
  }

}
