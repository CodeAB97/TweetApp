import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../service/userService/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registrationData = {
    userName : '',
    firstName: '',
    lastName: '',
    emailId: '',
    contactNumber: '',
    password: ''
  }

  confirmPassword = {
    cnfmpassword: ''
  }

  public duplicateUserFlag: boolean = false;
  public duplicateEmailFlag: boolean = false;
  public passwordMatchFlag: boolean = true;
  duplicateUserMessage: string = 'UserName is not unique';
  duplicateEmailIdMessage: string = 'EmailId is not unique';
  
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    
  }

  registerUser() {
    if(this.registrationData.password === this.confirmPassword.cnfmpassword) {
      this.passwordMatchFlag = true
      this.userService.registerUser(this.registrationData).subscribe(
        response => this.handleSuccessfulRegistration(response),
        error => this.handleUnsuccessfulRegistration(error)
      );
    } else {
      this.passwordMatchFlag = false
    }
  }

  handleSuccessfulRegistration(response: any) {
    this.router.navigate(['login'])
  }

  handleUnsuccessfulRegistration(error: HttpErrorResponse) {
    if(error.error.message === this.duplicateUserMessage) {
      this.duplicateUserFlag = true;
    } else if(error.error.message === this.duplicateEmailIdMessage) {
      this.duplicateUserFlag = false;
      this.duplicateEmailFlag = true;
    } else {
      this.router.navigate(['error'])
    }
  }

  clearDuplicateUserFlag() {
    this.duplicateUserFlag = false
  }

  clearDuplicateEmailFlag() {
    this.duplicateEmailFlag = false
  }

  clearPasswordMatchFlag() {
    this.passwordMatchFlag = true
  }

}
