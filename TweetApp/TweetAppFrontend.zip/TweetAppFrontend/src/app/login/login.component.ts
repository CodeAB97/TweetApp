import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtAuthenticationService } from '../service/jwtAuthenticationService/jwt-authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userCredentials = {
    userName: '',
    password: ''
  }

  public usernameErrorFlag: boolean = false;
  public passwordErrorFlag: boolean = false;
  usernameErrorMessage = 'Username not registered';
  passwordErrorMessage = 'Password is incorrect';

  constructor(private jwtAuthenticationService: JwtAuthenticationService, private router: Router) { }

  ngOnInit(): void {
  }

  authenticateUser() {
    this.jwtAuthenticationService.authenticateUser(this.userCredentials).subscribe(
      response => this.handleSuccessfulLogin(response),
      error => this.handleUnsuccesfulLogin(error)
    );
  }

  handleSuccessfulLogin(response: any) {
    this.router.navigate(['tweets'])
  }

  handleUnsuccesfulLogin(error : HttpErrorResponse) {
    if(error.error.message === this.usernameErrorMessage) {
      this.usernameErrorFlag = true;
    } else if(error.error.message === this.passwordErrorMessage) {
      this.usernameErrorFlag = false;
      this.passwordErrorFlag = true;
    } else {
      this.router.navigate(['error'])
    }
  }

  clearUsernameErrorFlag() {
    this.usernameErrorFlag = false
  }

  clearPasswordErrorFlag() {
    this.passwordErrorFlag = false
  }

}
