import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TweetTemplateComponent } from './tweet-template.component';

describe('TweetTemplateComponent', () => {
  let component: TweetTemplateComponent;
  let fixture: ComponentFixture<TweetTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TweetTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TweetTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
