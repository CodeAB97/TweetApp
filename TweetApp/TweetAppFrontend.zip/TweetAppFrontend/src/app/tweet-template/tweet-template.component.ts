import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { JwtAuthenticationService } from '../service/jwtAuthenticationService/jwt-authentication.service';
import { TweetService } from '../service/tweetService/tweet.service';
import { TweetsComponent } from '../tweets/tweets.component';

@Component({
  selector: 'app-tweet-template',
  templateUrl: './tweet-template.component.html',
  styleUrls: ['./tweet-template.component.css']
})
export class TweetTemplateComponent implements OnInit {

  @Input() tweet: any;

  onlyWhiteSpacesFlag = false;
  startsWithHashFlag = false
  hashMoreThanFiftyFlag = false
  tweetEditFlag = false;
  showEditAreaFlag= true;
  showReplyAreaFlag= true;
  tweetReply: any = ''
  editedTweetText: string = ''

  constructor(private jwtAuthenticationService: JwtAuthenticationService, private tweetService: TweetService, private tweetsComponent: TweetsComponent, private router: Router) { }

  ngOnInit(): void {
  }

  showEditArea(tweet: any) {
    if(tweet != null) {
      this.editedTweetText = tweet.tweetText
    }
    this.showEditAreaFlag = !this.showEditAreaFlag
    this.tweetEditFlag = !this.tweetEditFlag
    this.showReplyAreaFlag = true
  }

  showReplyArea() {
    this.showReplyAreaFlag = !this.showReplyAreaFlag
    this.showEditAreaFlag = true
    this.tweetEditFlag = false
  }

  isLiked(tweet: any) {
    if(tweet.likes.includes(this.jwtAuthenticationService.getAuthenticatedUser()))
      return true;
    else 
      return false; 
  }

  likeUnlikeTweet(tweet: any) {
    let user = this.jwtAuthenticationService.getAuthenticatedUser()
    this.tweetService.likeUnlikeTweet(user, tweet.id).subscribe(
      response => this.handleSuccesfulTweetLikeUnlike(),
      error => this.handleUnsuccesfulTweetLikeUnlike(error)
    )
  }

  handleSuccesfulTweetLikeUnlike() {
    this.tweetsComponent.refreshTweets()
  }

  handleUnsuccesfulTweetLikeUnlike(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  tweetOfAuthenticatedUser(tweet: any) {
    return tweet.userName === this.jwtAuthenticationService.getAuthenticatedUser()
  }

  updateTweet(tweet: any) {
    if(this.editedTweetText.trim().length) {
      if(this.editedTweetText.trim().startsWith('#')) {
        this.startsWithHashFlag = true
      } else {
        if(this.tweetService.processMessage(this.editedTweetText.trim())) {
          this.showEditArea(null);
          let userName = this.jwtAuthenticationService.getAuthenticatedUser()
          this.tweetService.updateTweet(userName, tweet.id, this.editedTweetText).subscribe(
            response => this.handleSuccesfulTweetUpdate(),
            error => this.handleUnsuccesfulTweetUpdate(error)
          )
        } else {
          this.hashMoreThanFiftyFlag = true
        }
      }
    } else {
      this.onlyWhiteSpacesFlag = true
    }
  }

  handleSuccesfulTweetUpdate() {
    this.tweetsComponent.refreshTweets()
  }

  handleUnsuccesfulTweetUpdate(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  deleteTweet(tweet: any) {
    let userName = this.jwtAuthenticationService.getAuthenticatedUser()
    this.tweetService.deleteTweet(userName, tweet.id).subscribe(
      response => this.handleSuccesfulTweetDelete(),
      error => this.handleUnsuccesfulTweetDelete(error)
    )
  }

  handleSuccesfulTweetDelete() {
    this.router.navigate(['tweets']).then(() => {
    window.location.reload();
    });
  }

  handleUnsuccesfulTweetDelete(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  replyOnTweet(tweet: any) {
    if(this.tweetReply.trim().length) {
      if(this.tweetReply.trim().startsWith('#')) {
        this.startsWithHashFlag = true
      } else {
        if(this.tweetService.processMessage(this.tweetReply.trim())) {
          let userName = this.jwtAuthenticationService.getAuthenticatedUser()
          this.tweetService.replyOnTweet(userName, tweet.id, this.tweetReply).subscribe(
            response => this.handleSuccesfulReplyEvent(),
            error => this.handleUnsuccesfulReplyEvent(error)
          )
        } else {
          this.hashMoreThanFiftyFlag = true
        }
      }
    } else {
      this.onlyWhiteSpacesFlag = true
    }
  }

  handleSuccesfulReplyEvent() {
    this.router.navigate(['tweets']).then(() => {
    window.location.reload();
    });
  }

  handleUnsuccesfulReplyEvent(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  clearFlags() {
    this.onlyWhiteSpacesFlag = false
    this.startsWithHashFlag = false
    this.hashMoreThanFiftyFlag = false
  }

}
