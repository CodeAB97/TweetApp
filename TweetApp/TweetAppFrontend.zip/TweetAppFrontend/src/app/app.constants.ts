export const USER_NAME = 'userName';
export const FIRST_NAME = 'FIRST_NAME';
export const LAST_NAME = 'LAST_NAME';
export const TOKEN = 'TOKEN';
export const OTP_USER = 'OTP_USER';
export const URL = 'localhost:8050'