import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

  errorMessage = 'ERROR OCCURED : PLEASE CONTACT SUPPORT AT'
  contactDetail = 'tweetapphelpline@gmail.com'

  constructor() { }

  ngOnInit(): void {
  }

}
