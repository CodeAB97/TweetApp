import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../service/userService/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  userDetailsList: any
  userName: any
  errorMessage = "Username doesn't exists"
  userFlag: any = true

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    this.userService.getAllUsers().subscribe(
      response => this.handleSuccesfulUsersFetch(response),
      error => this.handleUnsuccesfulUsersFetch(error)
    )
  }

  handleSuccesfulUsersFetch(response: any) {
    this.userDetailsList = response
  }

  handleUnsuccesfulUsersFetch(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  searchUser() {
    this.userService.searchByUserName(this.userName).subscribe(
      response => this.handleSuccesfulUserSearch(response),
      error => this.handleUnsccesfulUserSearch(error)
    )
  }

  handleSuccesfulUserSearch(response: any) {
    this.userFlag = true;
    this.userDetailsList = response
  }

  handleUnsccesfulUserSearch(error: HttpErrorResponse) {
    if(error.error.message === this.errorMessage) {
      this.userDetailsList = []
      this.userFlag = false;
    } else {
      this.router.navigate(['error'])
    }
  }

}
