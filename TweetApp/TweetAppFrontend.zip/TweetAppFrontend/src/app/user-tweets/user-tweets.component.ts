import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TweetService } from '../service/tweetService/tweet.service';

@Component({
  selector: 'app-user-tweets',
  templateUrl: './user-tweets.component.html',
  styleUrls: ['./user-tweets.component.css']
})
export class UserTweetsComponent implements OnInit {

  tweetList: any
  isTweetListEmpty = true

  constructor(private tweetService: TweetService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    let userName = this.route.snapshot.params['username']
    this.tweetService.getAllTweetsOfUser(userName).subscribe(
      response => this.handleSuccesfulTweetFetch(response),
      error => this.handleUnsccesfulTweetFetch(error)
    )
  }

  handleSuccesfulTweetFetch(response: any) {
    if(response.length) {
      this.tweetList = this.tweetService.setPostTime(response)
    } else {
      this.isTweetListEmpty = false
    }
  }

  handleUnsccesfulTweetFetch(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

}
