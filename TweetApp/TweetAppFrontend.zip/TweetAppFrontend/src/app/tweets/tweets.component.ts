import { HttpErrorResponse } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FIRST_NAME, LAST_NAME, USER_NAME } from '../app.constants';
import { JwtAuthenticationService } from '../service/jwtAuthenticationService/jwt-authentication.service';
import { TweetService } from '../service/tweetService/tweet.service';


@Component({
  selector: 'app-tweets',
  templateUrl: './tweets.component.html',
  styleUrls: ['./tweets.component.css']
})
@Injectable({
  providedIn: 'root'
})
export class TweetsComponent implements OnInit {

  tweet = {
    firstName: '',
    lastName: '',
    tweetText: ''
  }

  tweetReply = {
    replyText: ''
  }

  firstName: any
  lastName: any
  onlyWhiteSpacesFlag = false
  startsWithHashFlag = false
  hashMoreThanFiftyFlag = false
  tweetList: any

  constructor(private tweetService: TweetService, private router: Router) { }

  ngOnInit(): void {
    this.refreshTweets()
  }

  tweetPost() {
    if(this.tweet.tweetText.trim().length) {
      if(this.tweet.tweetText.trim().startsWith('#')) {
        this.startsWithHashFlag = true
      } else {
        if(this.tweetService.processMessage(this.tweet.tweetText.trim())) {
          this.firstName = sessionStorage.getItem(FIRST_NAME)
          this.tweet.firstName = this.firstName
          this.lastName = sessionStorage.getItem(LAST_NAME)
          this.tweet.lastName = this.lastName
          this.tweetService.postTweet(this.tweet).subscribe(
            response => this.handleSuccesfulTweetPosting(response),
            error => this.handleUnsuccesfulTweetPosting(error) 
          )
        } else {
          this.hashMoreThanFiftyFlag = true
        }
      }
    } else {
      this.onlyWhiteSpacesFlag = true
    }
  }

  handleSuccesfulTweetPosting(response: any) {
    this.refreshTweets()
    this.tweet.tweetText = ''
    this.router.navigate(['tweets'])
  }

  handleUnsuccesfulTweetPosting(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  refreshTweets() {
    this.tweetService.getAllTweets().subscribe(
      response => this.handleSuccesfulTweetListFetching(response),
      error => this.handleUnsuccesfulTweetListFetching(error)
    )
  }

  handleSuccesfulTweetListFetching(response: any) {
    response = this.tweetService.setPostTime(response)
    this.tweetList = response;
  }

  handleUnsuccesfulTweetListFetching(error: HttpErrorResponse) {
    this.router.navigate(['error'])
  }

  clearFlags() {
    this.onlyWhiteSpacesFlag = false
    this.startsWithHashFlag = false
    this.hashMoreThanFiftyFlag = false
  }

}
