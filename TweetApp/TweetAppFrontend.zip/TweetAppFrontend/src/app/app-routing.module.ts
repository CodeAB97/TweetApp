import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { RouteGuardService } from './service/routeGuardService/route-guard.service';
import { TweetTemplateComponent } from './tweet-template/tweet-template.component';
import { TweetsComponent } from './tweets/tweets.component';
import { UserTweetsComponent } from './user-tweets/user-tweets.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {path:'register', component: RegistrationComponent},
  {path:'login', component: LoginComponent},
  {path:'forgotpassword', component: ForgotPasswordComponent},
  {path:'tweets', component: TweetsComponent, canActivate: [RouteGuardService]},
  {path:'users', component: UserComponent, canActivate: [RouteGuardService]},
  {path:'usertweets/:username', component: UserTweetsComponent, canActivate: [RouteGuardService]},
  {path:'', component: LoginComponent},
  {path:'**', component: ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
